/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * Copyright (c) 2014-2017 Mentor Graphics Inc.
 */

#ifndef __MEDIA_IMX_H__
#define __MEDIA_IMX_H__

#include <linux/imx-media.h>

#endif
