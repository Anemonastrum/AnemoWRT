#!/bin/sh

# Set Timezone to Asia/Jakarta
uci set system.@system[0].timezone='WIB-7'
uci set system.@system[0].zonename='Asia/Jakarta'
uci commit

# Fix php8
grep -q ".php=/usr/bin/php-cgi" /etc/config/uhttpd;
uci set uhttpd.main.ubus_prefix='/ubus'
uci set uhttpd.main.interpreter='.php=/usr/bin/php-cgi'
uci set uhttpd.main.index_page='cgi-bin/luci'
uci add_list uhttpd.main.index_page='index.html'
uci add_list uhttpd.main.index_page='index.php'
uci commit uhttpd
/etc/init.d/uhttpd restart
[ -d /usr/lib/php8 ] && [ ! -d /usr/lib/php ] && ln -sf /usr/lib/php8 /usr/lib/php

# Permission
chmod +x /root/time.sh
chmod +x /usr/bin/hg680p.sh
chmod +x /usr/bin/internet-hg680p.sh

exit 0
