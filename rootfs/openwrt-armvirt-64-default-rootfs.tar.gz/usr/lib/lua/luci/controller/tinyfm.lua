module("luci.controller.tinyfm", package.seeall)
function index()
	entry({"admin", "services"}, firstchild(), "Services", 44).dependent=false
	entry({"admin", "services", "tinyfm"}, template("tinyfm"), _("File Manager"), 55).dependent=true
end