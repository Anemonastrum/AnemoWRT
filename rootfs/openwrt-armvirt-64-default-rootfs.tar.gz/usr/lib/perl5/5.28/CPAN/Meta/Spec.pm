
use 5.006;
use strict;
use warnings;
package CPAN::Meta::Spec;

our $VERSION = '2.150010';

1;




__END__

