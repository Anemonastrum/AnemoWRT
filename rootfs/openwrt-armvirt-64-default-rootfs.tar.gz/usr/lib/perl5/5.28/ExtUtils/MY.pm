package ExtUtils::MY;

use strict;
require ExtUtils::MM;

our $VERSION = '7.34';
$VERSION = eval $VERSION;
our @ISA = qw(ExtUtils::MM);

{
    package MY;
    our @ISA = qw(ExtUtils::MY);
}

sub DESTROY {}


