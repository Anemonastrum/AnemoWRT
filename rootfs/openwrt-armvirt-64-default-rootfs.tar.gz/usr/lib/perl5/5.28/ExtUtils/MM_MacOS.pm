package ExtUtils::MM_MacOS;

use strict;

our $VERSION = '7.34';
$VERSION = eval $VERSION;

sub new {
    die 'MacOS Classic (MacPerl) is no longer supported by MakeMaker';
}


1;
