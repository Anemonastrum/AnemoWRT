package ExtUtils::MM_VOS;

use strict;
our $VERSION = '7.34';
$VERSION = eval $VERSION;

require ExtUtils::MM_Unix;
our @ISA = qw(ExtUtils::MM_Unix);



sub extra_clean_files {
    return qw(*.kp);
}




1;
